BouwZeker V16 – professionele werkende basis

Dit pakket is een professionele werkende basisversie voor klant en aannemer.

Wat aanwezig is:
- registratie
- login
- klantdashboard
- aannemerdashboard
- project aanmaken
- aannemer koppelen
- milestones / fases
- berichten
- documenten toevoegen via URL
- betaalstatus voorbereiden

Techniek:
- Node.js + Express
- lokale JSON-opslag in data/store.json
- geen Stripe nodig om te testen

Starten:
1. pak de zip uit
2. kopieer .env.example naar .env
3. open terminal in de map
4. voer uit:
   npm install
   npm start
5. open:
   http://localhost:3000

Standaard accounts:
- klant@bouwzeker.nl / Welkom123!
- aannemer@bouwzeker.nl / Welkom123!
- admin@bouwzeker.nl / Welkom123!

Technische notities:
- dit is een eerste productiegerichte platformversie voor testgebruik
- voor verdere schaal kun je later PostgreSQL, echte uploads en Stripe toevoegen
