require("dotenv").config();
const bcrypt = require("bcryptjs");
const pool = require("../db");

async function ensureUser(name, email, password, role, company_name="", verification_status="niet_geverifieerd", kvk_number="") {
  const existing = await pool.query("SELECT id FROM users WHERE email = $1", [email]);
  if (existing.rows[0]) return existing.rows[0].id;
  const hash = await bcrypt.hash(password, 10);
  const result = await pool.query(
    "INSERT INTO users (name, email, password_hash, role, company_name, verification_status, kvk_number) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id",
    [name, email, hash, role, company_name, verification_status, kvk_number]
  );
  return result.rows[0].id;
}

async function run() {
  const adminId = await ensureUser("BouwZeker Beheer", "admin@bouwzeker.nl", "Welkom123!", "admin", "BouwZeker", "geverifieerd", "");
  const customerId = await ensureUser("Klant Account", "klant@bouwzeker.nl", "Welkom123!", "customer");
  const contractorId = await ensureUser("Aannemer Account", "aannemer@bouwzeker.nl", "Welkom123!", "contractor", "Jansen Bouw & Renovatie", "geverifieerd", "12345678");

  const p = await pool.query("SELECT id FROM projects WHERE title = $1", ["Badkamer renovatie"]);
  let projectId = p.rows[0]?.id;
  if (!projectId) {
    const pr = await pool.query(
      "INSERT INTO projects (title, description, location, budget, status, customer_id, contractor_id, payment_status) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id",
      ["Badkamer renovatie", "Volledige renovatie inclusief tegelwerk en sanitair.", "Rotterdam", 850000, "assigned", customerId, contractorId, "voorbereid"]
    );
    projectId = pr.rows[0].id;

    await pool.query(
      "INSERT INTO milestones (project_id, title, amount, status, position) VALUES ($1,$2,$3,$4,$5),($1,$6,$7,$8,$9),($1,$10,$11,$12,$13)",
      [projectId, "Start werkzaamheden", 250000, "approved", 1, "Halverwege project", 300000, "submitted", 2, "Oplevering", 300000, "locked", 3]
    );
    await pool.query(
      "INSERT INTO messages (project_id, sender_id, sender_name, text) VALUES ($1,$2,$3,$4),($1,$5,$6,$7)",
      [projectId, customerId, "Klant Account", "Wanneer kunnen jullie starten?", contractorId, "Aannemer Account", "Wij kunnen volgende week beginnen."]
    );
    await pool.query(
      "INSERT INTO documents (project_id, name, url) VALUES ($1,$2,$3)",
      [projectId, "Offerte badkamer.pdf", "#"]
    );
    await pool.query(
      "INSERT INTO contracts (project_id, title, body, status) VALUES ($1,$2,$3,$4)",
      [projectId, "Aannemingsovereenkomst badkamer", "Partijen spreken af dat werkzaamheden in 3 fases worden uitgevoerd en per fase worden beoordeeld.", "actief"]
    );
    await pool.query(
      "INSERT INTO payment_accounts (user_id, provider, account_status, external_account_id) VALUES ($1,$2,$3,$4)",
      [contractorId, "stripe", "voorbereid_voor_koppeling", ""]
    );
  }


  await pool.query(
    "INSERT INTO notifications (user_id, title, body) VALUES ($1,$2,$3),($4,$5,$6) ON CONFLICT DO NOTHING",
    [customerId, "Project update", "Je project Badkamer renovatie heeft een nieuwe status.", contractorId, "Nieuwe opdracht", "Je bent gekoppeld aan Badkamer renovatie."]
  );

  console.log("Seed klaar.");

  await pool.end();
}

run().catch(err => { console.error(err); process.exit(1); });
