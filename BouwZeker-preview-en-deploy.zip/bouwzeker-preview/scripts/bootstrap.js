require("dotenv").config();
const { execSync } = require("child_process");

function run(cmd) {
  console.log(`> ${cmd}`);
  execSync(cmd, { stdio: "inherit" });
}

try {
  run("node scripts/migrate.js");
  run("node scripts/seed.js");
  run("node server.js");
} catch (err) {
  console.error("Bootstrap mislukt.");
  process.exit(1);
}
