require("dotenv").config();
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const bcrypt = require("bcryptjs");
const express = require("express");
const nodemailer = require("nodemailer");
const multer = require("multer");
const pool = require("./db");

const app = express();
const PORT = process.env.PORT || 3000;

const uploadsDir = path.join(__dirname, "uploads");
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });

const upload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, uploadsDir),
    filename: (_req, file, cb) => {
      const safe = file.originalname.replace(/[^a-zA-Z0-9._-]/g, "_");
      cb(null, `${Date.now()}-${safe}`);
    }
  }),
  limits: { fileSize: 8 * 1024 * 1024 }
});

app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true }));
app.use(express.static(__dirname));
app.use("/uploads", express.static(uploadsDir));

app.use((req, res, next) => {
  res.setHeader("X-Frame-Options", "SAMEORIGIN");
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  next();
});

const requestBuckets = new Map();
function rateLimit(windowMs, max) {
  return (req, res, next) => {
    const key = `${req.ip}:${req.path}`;
    const now = Date.now();
    const current = requestBuckets.get(key) || { count: 0, resetAt: now + windowMs };
    if (now > current.resetAt) {
      current.count = 0;
      current.resetAt = now + windowMs;
    }
    current.count += 1;
    requestBuckets.set(key, current);
    if (current.count > max) return res.status(429).json({ error: "Te veel verzoeken. Probeer het later opnieuw." });
    next();
  };
}

function pub(user) {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    company_name: user.company_name || "",
    verification_status: user.verification_status || "niet_geverifieerd",
    kvk_number: user.kvk_number || ""
  };
}

async function auth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  if (!token) return res.status(401).json({ error: "Niet ingelogd." });
  const result = await pool.query(
    `SELECT u.id, u.name, u.email, u.role, u.company_name, u.verification_status, u.kvk_number
     FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token = $1`,
    [token]
  );
  const user = result.rows[0];
  if (!user) return res.status(401).json({ error: "Niet ingelogd." });
  req.user = user;
  req.token = token;
  next();
}

function makeVerificationToken() {
  return crypto.randomBytes(24).toString("hex");
}

async function sendMail({ to, replyTo, subject, text }) {
  if (!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASS) return false;
  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: false,
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
  });
  await transporter.sendMail({
    from: `"BouwZeker" <${process.env.SMTP_USER}>`,
    to,
    replyTo,
    subject,
    text
  });
  return true;
}

app.get("/api/health", (_req, res) => res.json({ ok: true, app: "BouwZeker V17 Startup" }));

app.post("/api/auth/register", rateLimit(10 * 60 * 1000, 15), async (req, res) => {
  const { name, email, password, role, company_name = "" } = req.body || {};
  if (!name || !email || !password || !role) return res.status(400).json({ error: "Vul alle verplichte velden in." });
  if (!["customer", "contractor"].includes(role)) return res.status(400).json({ error: "Ongeldige rol." });
  const existing = await pool.query("SELECT id FROM users WHERE email = $1", [String(email).toLowerCase()]);
  if (existing.rows[0]) return res.status(400).json({ error: "E-mailadres bestaat al." });

  const hash = await bcrypt.hash(password, 10);
  const userRes = await pool.query(
    "INSERT INTO users (name, email, password_hash, role, company_name) VALUES ($1,$2,$3,$4,$5) RETURNING id, name, email, role, company_name, verification_status, kvk_number",
    [name, String(email).toLowerCase(), hash, role, company_name]
  );

  const token = crypto.randomBytes(24).toString("hex");
  await pool.query("INSERT INTO sessions (token, user_id) VALUES ($1,$2)", [token, userRes.rows[0].id]);

  const verifyToken = makeVerificationToken();
  await pool.query(
    "INSERT INTO email_verification_tokens (user_id, token, expires_at) VALUES ($1,$2,NOW() + INTERVAL '2 days')",
    [userRes.rows[0].id, verifyToken]
  );

  const appUrl = process.env.APP_BASE_URL || `http://localhost:${PORT}`;
  await sendMail({
    to: userRes.rows[0].email,
    subject: "Bevestig je e-mailadres voor BouwZeker",
    text: `Welkom bij BouwZeker. Open deze link om je e-mailadres te bevestigen: ${appUrl}/verify-email.html?token=${verifyToken}`
  }).catch(() => {});

  res.status(201).json({ token, user: pub(userRes.rows[0]) });
});

app.post("/api/auth/login", rateLimit(10 * 60 * 1000, 30), async (req, res) => {
  const { email, password } = req.body || {};
  const result = await pool.query("SELECT * FROM users WHERE email = $1", [String(email).toLowerCase()]);
  const user = result.rows[0];
  if (!user) return res.status(401).json({ error: "Ongeldige inloggegevens." });
  const ok = await bcrypt.compare(password || "", user.password_hash);
  if (!ok) return res.status(401).json({ error: "Ongeldige inloggegevens." });

  const token = crypto.randomBytes(24).toString("hex");
  await pool.query("INSERT INTO sessions (token, user_id) VALUES ($1,$2)", [token, user.id]);
  res.json({ token, user: pub(user) });
});

app.post("/api/auth/logout", auth, async (req, res) => {
  await pool.query("DELETE FROM sessions WHERE token = $1", [req.token]);
  res.json({ ok: true });
});

app.get("/api/me", auth, async (req, res) => res.json(pub(req.user)));

app.get("/api/auth/verify-email", async (req, res) => {
  const token = String(req.query.token || "");
  if (!token) return res.status(400).json({ error: "Token ontbreekt." });

  const result = await pool.query(
    `SELECT * FROM email_verification_tokens
     WHERE token = $1 AND used_at IS NULL AND expires_at > NOW()`,
    [token]
  );
  const row = result.rows[0];
  if (!row) return res.status(400).json({ error: "Verificatielink is ongeldig of verlopen." });

  await pool.query("UPDATE email_verification_tokens SET used_at = NOW() WHERE id = $1", [row.id]);
  await pool.query("UPDATE users SET verification_status = 'geverifieerd' WHERE id = $1", [row.user_id]);
  res.json({ ok: true, message: "E-mailadres bevestigd." });
});

app.get("/api/notifications", auth, async (req, res) => {
  const result = await pool.query("SELECT * FROM notifications WHERE user_id = $1 ORDER BY created_at DESC LIMIT 20", [req.user.id]);
  res.json(result.rows);
});

app.post("/api/notifications/:id/read", auth, async (req, res) => {
  await pool.query("UPDATE notifications SET is_read = TRUE WHERE id = $1 AND user_id = $2", [req.params.id, req.user.id]);
  res.json({ ok: true });
});

app.get("/api/contractors", auth, async (_req, res) => {
  const result = await pool.query("SELECT id, name, email, role, company_name, verification_status, kvk_number FROM users WHERE role = 'contractor' ORDER BY created_at DESC");
  res.json(result.rows.map(pub));
});

app.get("/api/admin/overview", auth, async (req, res) => {
  if (req.user.role !== "admin") return res.status(403).json({ error: "Geen toegang." });
  const users = await pool.query("SELECT COUNT(*)::int AS count FROM users");
  const projects = await pool.query("SELECT COUNT(*)::int AS count FROM projects");
  const contractors = await pool.query("SELECT COUNT(*)::int AS count FROM users WHERE role = 'contractor'");
  const verified = await pool.query("SELECT COUNT(*)::int AS count FROM users WHERE role = 'contractor' AND verification_status = 'geverifieerd'");
  const contracts = await pool.query("SELECT COUNT(*)::int AS count FROM contracts");
  res.json({
    users: users.rows[0].count,
    projects: projects.rows[0].count,
    contractors: contractors.rows[0].count,
    verified_contractors: verified.rows[0].count,
    contracts: contracts.rows[0].count
  });
});

app.get("/api/admin/contractors", auth, async (req, res) => {
  if (req.user.role !== "admin") return res.status(403).json({ error: "Geen toegang." });
  const result = await pool.query("SELECT id, name, email, role, company_name, verification_status, kvk_number FROM users WHERE role = 'contractor' ORDER BY created_at DESC");
  res.json(result.rows.map(pub));
});

app.post("/api/admin/contractors/:id/verify", auth, async (req, res) => {
  if (req.user.role !== "admin") return res.status(403).json({ error: "Geen toegang." });
  await pool.query("UPDATE users SET verification_status = 'geverifieerd' WHERE id = $1 AND role = 'contractor'", [req.params.id]);
  res.json({ ok: true });
});

app.get("/api/projects", auth, async (req, res) => {
  let q = "SELECT * FROM projects ORDER BY created_at DESC";
  let params = [];
  if (req.user.role === "customer") { q = "SELECT * FROM projects WHERE customer_id = $1 ORDER BY created_at DESC"; params = [req.user.id]; }
  else if (req.user.role === "contractor") { q = "SELECT * FROM projects WHERE contractor_id = $1 ORDER BY created_at DESC"; params = [req.user.id]; }
  const result = await pool.query(q, params);
  res.json(result.rows);
});

app.get("/api/projects/:id", auth, async (req, res) => {
  const p = await pool.query("SELECT * FROM projects WHERE id = $1", [req.params.id]);
  const project = p.rows[0];
  if (!project) return res.status(404).json({ error: "Project niet gevonden." });
  if (!(req.user.role === "admin" || project.customer_id === req.user.id || project.contractor_id === req.user.id)) {
    return res.status(403).json({ error: "Geen toegang." });
  }
  const milestones = await pool.query("SELECT * FROM milestones WHERE project_id = $1 ORDER BY position ASC", [project.id]);
  const messages = await pool.query("SELECT * FROM messages WHERE project_id = $1 ORDER BY created_at ASC", [project.id]);
  const documents = await pool.query("SELECT * FROM documents WHERE project_id = $1 ORDER BY created_at DESC", [project.id]);
  const contracts = await pool.query("SELECT * FROM contracts WHERE project_id = $1 ORDER BY created_at DESC", [project.id]);
  res.json({ ...project, milestones: milestones.rows, messages: messages.rows, documents: documents.rows, contracts: contracts.rows });
});

app.post("/api/projects", auth, async (req, res) => {
  if (!["customer", "admin"].includes(req.user.role)) return res.status(403).json({ error: "Alleen klanten kunnen projecten aanmaken." });
  const { title, description = "", location = "", budget = 0, contractor_id = "", milestones = [] } = req.body || {};
  if (!title || !budget) return res.status(400).json({ error: "Titel en budget zijn verplicht." });

  const pr = await pool.query(
    "INSERT INTO projects (title, description, location, budget, status, customer_id, contractor_id, payment_status) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *",
    [title, description, location, Number(budget), contractor_id ? "assigned" : "open", req.user.id, contractor_id || null, "voorbereid"]
  );
  const project = pr.rows[0];
  let position = 1;
  for (const m of milestones) {
    if (m.title && Number(m.amount) > 0) {
      await pool.query("INSERT INTO milestones (project_id, title, amount, status, position) VALUES ($1,$2,$3,$4,$5)", [project.id, m.title, Number(m.amount), position === 1 ? "pending_review" : "locked", position]);
      position++;
    }
  }
  res.status(201).json(project);
});

app.post("/api/projects/:id/messages", auth, async (req, res) => {
  const { text } = req.body || {};
  if (!text) return res.status(400).json({ error: "Bericht mag niet leeg zijn." });
  const p = await pool.query("SELECT * FROM projects WHERE id = $1", [req.params.id]);
  const project = p.rows[0];
  if (!project) return res.status(404).json({ error: "Project niet gevonden." });
  if (!(req.user.role === "admin" || project.customer_id === req.user.id || project.contractor_id === req.user.id)) return res.status(403).json({ error: "Geen toegang." });
  const result = await pool.query("INSERT INTO messages (project_id, sender_id, sender_name, text) VALUES ($1,$2,$3,$4) RETURNING *", [project.id, req.user.id, req.user.name, text]);
  res.status(201).json(result.rows[0]);
});

app.post("/api/projects/:id/documents", auth, async (req, res) => {
  const { name, url } = req.body || {};
  if (!name || !url) return res.status(400).json({ error: "Naam en URL zijn verplicht." });
  const p = await pool.query("SELECT * FROM projects WHERE id = $1", [req.params.id]);
  const project = p.rows[0];
  if (!project) return res.status(404).json({ error: "Project niet gevonden." });
  if (!(req.user.role === "admin" || project.customer_id === req.user.id || project.contractor_id === req.user.id)) return res.status(403).json({ error: "Geen toegang." });
  const result = await pool.query("INSERT INTO documents (project_id, name, url) VALUES ($1,$2,$3) RETURNING *", [project.id, name, url]);
  res.status(201).json(result.rows[0]);
});

app.post("/api/projects/:id/upload", auth, upload.single("file"), async (req, res) => {
  const p = await pool.query("SELECT * FROM projects WHERE id = $1", [req.params.id]);
  const project = p.rows[0];
  if (!project) return res.status(404).json({ error: "Project niet gevonden." });
  if (!(req.user.role === "admin" || project.customer_id === req.user.id || project.contractor_id === req.user.id)) return res.status(403).json({ error: "Geen toegang." });
  if (!req.file) return res.status(400).json({ error: "Geen bestand geüpload." });
  const url = `/uploads/${req.file.filename}`;
  const result = await pool.query("INSERT INTO documents (project_id, name, url) VALUES ($1,$2,$3) RETURNING *", [project.id, req.file.originalname, url]);
  res.status(201).json(result.rows[0]);
});

app.get("/api/projects/:id/contracts", auth, async (req, res) => {
  const p = await pool.query("SELECT * FROM projects WHERE id = $1", [req.params.id]);
  const project = p.rows[0];
  if (!project) return res.status(404).json({ error: "Project niet gevonden." });
  if (!(req.user.role === "admin" || project.customer_id === req.user.id || project.contractor_id === req.user.id)) return res.status(403).json({ error: "Geen toegang." });
  const result = await pool.query("SELECT * FROM contracts WHERE project_id = $1 ORDER BY created_at DESC", [project.id]);
  res.json(result.rows);
});

app.post("/api/projects/:id/contracts", auth, async (req, res) => {
  const { title, body } = req.body || {};
  if (!title || !body) return res.status(400).json({ error: "Titel en inhoud zijn verplicht." });
  const p = await pool.query("SELECT * FROM projects WHERE id = $1", [req.params.id]);
  const project = p.rows[0];
  if (!project) return res.status(404).json({ error: "Project niet gevonden." });
  if (!(req.user.role === "admin" || project.customer_id === req.user.id)) return res.status(403).json({ error: "Alleen klant of beheer kan contracten toevoegen." });
  const result = await pool.query("INSERT INTO contracts (project_id, title, body, status) VALUES ($1,$2,$3,$4) RETURNING *", [project.id, title, body, "actief"]);
  res.status(201).json(result.rows[0]);
});

app.post("/api/projects/:id/milestones/:milestoneId/status", auth, async (req, res) => {
  const { status } = req.body || {};
  const allowed = ["pending_review","submitted","approved","locked","completed"];
  if (!allowed.includes(status)) return res.status(400).json({ error: "Ongeldige status." });

  const p = await pool.query("SELECT * FROM projects WHERE id = $1", [req.params.id]);
  const project = p.rows[0];
  if (!project) return res.status(404).json({ error: "Project niet gevonden." });

  const m = await pool.query("SELECT * FROM milestones WHERE id = $1 AND project_id = $2", [req.params.milestoneId, project.id]);
  const milestone = m.rows[0];
  if (!milestone) return res.status(404).json({ error: "Milestone niet gevonden." });

  if (status === "submitted" && !(req.user.role === "contractor" && project.contractor_id === req.user.id)) return res.status(403).json({ error: "Alleen de gekoppelde aannemer kan een fase indienen." });
  if (status === "approved" && !(req.user.role === "admin" || project.customer_id === req.user.id)) return res.status(403).json({ error: "Alleen de klant kan een fase goedkeuren." });

  await pool.query("UPDATE milestones SET status = $1 WHERE id = $2", [status, milestone.id]);
  if (status === "approved") {
    await pool.query("UPDATE milestones SET status = 'pending_review' WHERE project_id = $1 AND position = $2 AND status = 'locked'", [project.id, milestone.position + 1]);
  }
  res.json({ ok: true });
});

app.get("/api/payment-account", auth, async (req, res) => {
  const result = await pool.query("SELECT * FROM payment_accounts WHERE user_id = $1 ORDER BY created_at DESC LIMIT 1", [req.user.id]);
  res.json(result.rows[0] || { provider: "stripe", account_status: "nog_niet_gekoppeld", external_account_id: "" });
});

app.post("/api/payment-account/prepare", auth, async (req, res) => {
  if (req.user.role !== "contractor") return res.status(403).json({ error: "Alleen aannemers kunnen een betaalaccount voorbereiden." });
  const existing = await pool.query("SELECT * FROM payment_accounts WHERE user_id = $1 LIMIT 1", [req.user.id]);
  if (existing.rows[0]) {
    await pool.query("UPDATE payment_accounts SET account_status = 'voorbereid_voor_koppeling' WHERE user_id = $1", [req.user.id]);
  } else {
    await pool.query("INSERT INTO payment_accounts (user_id, provider, account_status, external_account_id) VALUES ($1,$2,$3,$4)", [req.user.id, "stripe", "voorbereid_voor_koppeling", ""]);
  }
  res.json({ ok: true, message: "Stripe-account is voorbereid voor latere koppeling." });
});

app.post("/api/projects/:id/payment-placeholder", auth, async (req, res) => {
  const p = await pool.query("SELECT * FROM projects WHERE id = $1", [req.params.id]);
  const project = p.rows[0];
  if (!project) return res.status(404).json({ error: "Project niet gevonden." });
  if (!(req.user.role === "admin" || project.customer_id === req.user.id)) return res.status(403).json({ error: "Geen toegang." });
  await pool.query("UPDATE projects SET payment_status = $1 WHERE id = $2", ["gereed_voor_stripe_koppeling", project.id]);
  res.json({ ok: true, message: "Betalingsmoment is vastgelegd. Stripe kan later direct worden gekoppeld." });
});

app.post("/api/contact", rateLimit(10 * 60 * 1000, 20), async (req, res) => {
  const { name, email, subject, message } = req.body || {};
  if (!name || !email || !message) return res.status(400).json({ error: "Vul naam, e-mail en bericht in." });
  if (!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASS || !process.env.CONTACT_TO) {
    console.log("CONTACT MESSAGE", { name, email, subject, message });
    return res.json({ ok: true, message: "Bericht ontvangen. Stel SMTP in om e-mails echt te versturen." });
  }
  try {
    await sendMail({
      to: process.env.CONTACT_TO,
      replyTo: email,
      subject: subject || "Nieuw bericht via BouwZeker",
      text: `Naam: ${name}\nE-mail: ${email}\n\nBericht:\n${message}`
    });
    res.json({ ok: true, message: "Bericht verzonden." });
  } catch {
    res.status(500).json({ error: "Mail verzenden mislukt. Controleer SMTP instellingen." });
  }
});

app.get("*", (req, res, next) => {
  if (req.path.startsWith("/api/")) return next();
  const filePath = path.join(__dirname, req.path);
  if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) return res.sendFile(filePath);
  if (fs.existsSync(filePath + ".html")) return res.sendFile(filePath + ".html");
  const clean = req.path.replace(/^\/+/, "");
  if (clean) {
    const htmlTarget = path.join(__dirname, `${clean}.html`);
    if (fs.existsSync(htmlTarget)) return res.sendFile(htmlTarget);
  }
  return res.sendFile(path.join(__dirname, "index.html"));
});

app.listen(PORT, () => console.log(`BouwZeker V17 draait op poort ${PORT}`));
