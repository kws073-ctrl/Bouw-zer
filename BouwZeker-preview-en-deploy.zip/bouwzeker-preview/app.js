const api = {
  async request(path, options = {}) {
    const token = localStorage.getItem("bouwzeker_token");
    const headers = Object.assign({}, options.headers || {});
    if (token) headers["Authorization"] = `Bearer ${token}`;
    if (!(options.body instanceof FormData) && !headers["Content-Type"] && options.body) headers["Content-Type"] = "application/json";
    let res;
    try { res = await fetch(path, { ...options, headers }); } catch { throw new Error("Verbinding mislukt. Probeer het opnieuw."); }
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || "Er ging iets mis.");
    return data;
  }
};

function currency(cents){ return new Intl.NumberFormat("nl-NL",{style:"currency",currency:"EUR"}).format((cents||0)/100); }
function currentUser(){ try { return JSON.parse(localStorage.getItem("bouwzeker_user") || "null"); } catch { return null; } }
function setSession(data){ localStorage.setItem("bouwzeker_token", data.token); localStorage.setItem("bouwzeker_user", JSON.stringify(data.user)); }
function clearSession(){ localStorage.removeItem("bouwzeker_token"); localStorage.removeItem("bouwzeker_user"); }
function afterLogin(user){ location.href = user.role === "contractor" ? "dashboard-aannemer.html" : user.role === "admin" ? "admin.html" : "dashboard-klant.html"; }
function requireAuth(redirect = true){ const token=localStorage.getItem("bouwzeker_token"); if(!token && redirect){ location.href="login.html"; return false; } return !!token; }
function setCurrentUserLabel(){ const u=currentUser(); document.querySelectorAll("[data-current-user]").forEach(el=>el.textContent=u?`${u.name} (${u.role})`:"Niet ingelogd"); }
function wireMenu(){ const t=document.querySelector(".mobile-toggle"), m=document.querySelector(".menu"); if(t&&m) t.addEventListener("click",()=>m.classList.toggle("open")); }
function wireCookies(){ const key="bouwzeker_cookie_choice"; const banner=document.querySelector(".cookie-banner"); if(!banner) return; if(!localStorage.getItem(key)) banner.classList.add("show"); banner.querySelectorAll("[data-cookie-choice]").forEach(btn=>btn.addEventListener("click",()=>{localStorage.setItem(key,btn.getAttribute("data-cookie-choice"));banner.classList.remove("show")}));}
function wireFaq(){ document.querySelectorAll(".faq-item button").forEach(btn=>btn.addEventListener("click",()=>btn.parentElement.classList.toggle("open"))); }
function showNotice(targetId, text){ const el=document.getElementById(targetId); if(el) el.innerHTML=`<div class="notice">${text}</div>`; }

async function onRegister(e){ e.preventDefault(); const data={name:name.value,email:email.value,password:password.value,role:role.value,company_name:company_name.value}; const result=await api.request("/api/auth/register",{method:"POST",body:JSON.stringify(data)}); setSession(result); afterLogin(result.user); }
async function onLogin(e){ e.preventDefault(); const data={email:email.value,password:password.value}; const result=await api.request("/api/auth/login",{method:"POST",body:JSON.stringify(data)}); setSession(result); afterLogin(result.user); }
async function logout(){ try{ await api.request("/api/auth/logout",{method:"POST"}); }catch{} clearSession(); location.href="index.html"; }

async function loadProjects(containerId, role){
  const box=document.getElementById(containerId); if(!box) return;
  const projects=await api.request("/api/projects");
  if(!projects.length){ box.innerHTML=`<div class="notice">Nog geen projecten gevonden.</div>`; return; }
  box.innerHTML=projects.map(p=>`<div class="card panel"><div class="info-row"><div><strong>${p.title}</strong><div class="small">${p.location||"-"}</div></div><span class="badge info">${p.status}</span></div><div class="small" style="margin-top:10px">${p.description||""}</div><div class="small" style="margin-top:10px">Budget: ${currency(p.budget)}</div><div class="stack" style="margin-top:14px"><a class="btn btn-primary" href="project.html?id=${p.id}">Open project</a>${role==="customer"?`<a class="btn btn-secondary" href="betaling.html?id=${p.id}">Betaling</a>`:""}</div></div>`).join("");
}
async function loadContractors(){
  const select=document.getElementById("contractor_id"); if(!select) return;
  const contractors=await api.request("/api/contractors");
  select.innerHTML=`<option value="">Kies aannemer</option>` + contractors.map(c=>`<option value="${c.id}">${c.company_name || c.name} ${c.verification_status==="geverifieerd"?"✅":""}</option>`).join("");
}
async function createProject(e){
  e.preventDefault();
  const milestones=[
    {title:mile1_title.value, amount:Math.round(Number(mile1_amount.value||0)*100)},
    {title:mile2_title.value, amount:Math.round(Number(mile2_amount.value||0)*100)},
    {title:mile3_title.value, amount:Math.round(Number(mile3_amount.value||0)*100)}
  ].filter(m=>m.title && m.amount>0);
  const data={title:title.value,description:description.value,location:location.value,budget:Math.round(Number(budget.value||0)*100),contractor_id:contractor_id.value,milestones};
  const project=await api.request("/api/projects",{method:"POST",body:JSON.stringify(data)});
  location.href=`project.html?id=${project.id}`;
}
function statusLabel(status){ return {pending_review:"Klaar om te starten",submitted:"Ingediend",approved:"Goedgekeurd",locked:"Vergrendeld",completed:"Afgerond"}[status] || status; }

async function loadProjectDetail(){
  const wrap=document.getElementById("project-detail"); if(!wrap) return;
  const id=new URLSearchParams(location.search).get("id"); if(!id){ wrap.innerHTML=`<div class="notice">Geen project geselecteerd.</div>`; return; }
  const project=await api.request(`/api/projects/${id}`);
  const me=currentUser(); const isCustomer=me && (me.role==="customer"||me.role==="admin");
  wrap.innerHTML=`<div class="grid-2"><section class="card panel"><span class="eyebrow">Projectoverzicht</span><h1 style="font-size:2.2rem;margin-top:14px">${project.title}</h1><p class="muted">${project.description||""}</p><div class="notice" style="margin:18px 0">Status project: ${project.status}. Betaling: ${project.payment_status}.</div><h3>Milestones</h3><div class="timeline">${(project.milestones||[]).map(m=>`<div class="timeline-item"><div class="dot ${m.status==="approved"?"done":(m.status==="submitted"||m.status==="pending_review")?"wait":""}"></div><div><strong>${m.title}</strong><div class="small">${statusLabel(m.status)}</div></div><strong>${currency(m.amount)}</strong></div>`).join("")}</div><div class="stack" style="margin-top:18px">${(!isCustomer && project.contractor_id===me.id)?`<button class="btn btn-primary" type="button" onclick="submitCurrentMilestone('${project.id}')">Fase indienen</button>`:""}${(isCustomer)?`<button class="btn btn-primary" type="button" onclick="approveCurrentMilestone('${project.id}')">Huidige fase goedkeuren</button>`:""}${(isCustomer)?`<button class="btn btn-secondary" type="button" onclick="preparePayment('${project.id}')">Betalingsmoment vastleggen</button>`:""}</div></section><aside class="card panel"><h3>Projectinformatie</h3><div class="info-row"><span class="muted">Budget</span><strong>${currency(project.budget)}</strong></div><div class="info-row"><span class="muted">Locatie</span><strong>${project.location||"-"}</strong></div><div class="info-row"><span class="muted">Berichten</span><strong>${(project.messages||[]).length}</strong></div><div class="info-row"><span class="muted">Documenten</span><strong>${(project.documents||[]).length}</strong></div><div class="info-row"><span class="muted">Contracten</span><strong>${(project.contracts||[]).length}</strong></div></aside></div>`;
  const docs=document.getElementById("documents-list"); if(docs) docs.innerHTML=(project.documents||[]).map(d=>`<div class="project-item"><strong>${d.name}</strong><div class="small">${d.url}</div></div>`).join("") || `<div class="notice">Nog geen documenten.</div>`;
  const msgs=document.getElementById("messages-list"); if(msgs) msgs.innerHTML=(project.messages||[]).map(m=>`<div class="project-item"><strong>${m.sender_name}</strong><div class="small">${m.text}</div></div>`).join("") || `<div class="notice">Nog geen berichten.</div>`;
  const contracts=document.getElementById("contracts-list"); if(contracts) contracts.innerHTML=(project.contracts||[]).map(c=>`<div class="project-item"><strong>${c.title}</strong><div class="small">${c.body}</div></div>`).join("") || `<div class="notice">Nog geen contracten.</div>`;
  const msgForm=document.getElementById("message-form"); if(msgForm) msgForm.onsubmit=async e=>{e.preventDefault(); await api.request(`/api/projects/${project.id}/messages`,{method:"POST",body:JSON.stringify({text:message_text.value})}); location.reload();};
  const docForm=document.getElementById("document-form"); if(docForm) docForm.onsubmit=async e=>{e.preventDefault(); await api.request(`/api/projects/${project.id}/documents`,{method:"POST",body:JSON.stringify({name:doc_name.value,url:doc_url.value})}); location.reload();};
  const contractForm=document.getElementById("contract-form"); if(contractForm) contractForm.onsubmit=async e=>{e.preventDefault(); await api.request(`/api/projects/${project.id}/contracts`,{method:"POST",body:JSON.stringify({title:contract_title.value,body:contract_body.value})}); location.reload();};
}
async function submitCurrentMilestone(projectId){ const project=await api.request(`/api/projects/${projectId}`); const milestone=(project.milestones||[]).find(m=>m.status==="pending_review"); if(!milestone) return alert("Geen fase gevonden."); await api.request(`/api/projects/${projectId}/milestones/${milestone.id}/status`,{method:"POST",body:JSON.stringify({status:"submitted"})}); location.reload(); }
async function approveCurrentMilestone(projectId){ const project=await api.request(`/api/projects/${projectId}`); const milestone=(project.milestones||[]).find(m=>m.status==="submitted"||m.status==="pending_review"); if(!milestone) return alert("Geen fase gevonden."); await api.request(`/api/projects/${projectId}/milestones/${milestone.id}/status`,{method:"POST",body:JSON.stringify({status:"approved"})}); location.reload(); }
async function preparePayment(projectId){ const result=await api.request(`/api/projects/${projectId}/payment-placeholder`,{method:"POST"}); alert(result.message); location.reload(); }
async function loadPaymentPage(){ const box=document.getElementById("payment-box"); if(!box) return; const id=new URLSearchParams(location.search).get("id"); if(!requireAuth(false)){ box.innerHTML=`<div class="notice">Log eerst in om een betalingspagina te bekijken.</div>`; return; } if(!id){ box.innerHTML=`<div class="notice">Geen project geselecteerd. Open eerst een project vanuit het dashboard.</div>`; return; } const project=await api.request(`/api/projects/${id}`); const current=(project.milestones||[]).find(m=>m.status==="submitted"||m.status==="pending_review")||project.milestones?.[0]; box.innerHTML=`<div class="card panel"><h2>${project.title}</h2><p class="small">Deze betaalpagina is klaar voor latere Stripe-koppeling.</p><div class="info-row"><span>Fase</span><strong>${current?current.title:"-"}</strong></div><div class="info-row"><span>Bedrag</span><strong>${current?currency(current.amount):"-"}</strong></div><div class="info-row"><span>Status</span><span class="badge warning">${project.payment_status}</span></div><div class="stack" style="margin-top:16px"><button class="btn btn-primary" type="button" onclick="preparePayment('${project.id}')">Betalingsmoment vastleggen</button><a class="btn btn-secondary" href="project.html?id=${project.id}">Terug naar project</a></div></div>`; }
async function onContact(e){ e.preventDefault(); const data={name:contact_name.value,email:contact_email.value,subject:contact_subject.value,message:contact_message.value}; const result=await api.request("/api/contact",{method:"POST",body:JSON.stringify(data)}); alert(result.message||"Bericht verzonden."); e.target.reset(); }
async function loadAdmin(){ const box=document.getElementById("admin-overview"); if(!box) return; const stats=await api.request("/api/admin/overview"); const contractors=await api.request("/api/admin/contractors"); box.innerHTML=`<div class="grid-3"><div class="card panel"><h3>Gebruikers</h3><h2>${stats.users}</h2></div><div class="card panel"><h3>Projecten</h3><h2>${stats.projects}</h2></div><div class="card panel"><h3>Geverifieerde aannemers</h3><h2>${stats.verified_contractors}</h2></div></div><div class="card panel" style="margin-top:18px"><h3>Aannemer verificatie</h3><div class="project-list">${contractors.map(c=>`<div class="project-item"><div class="info-row"><div><strong>${c.company_name || c.name}</strong><div class="small">${c.email} • KVK: ${c.kvk_number || "-"}</div></div><span class="badge ${c.verification_status==="geverifieerd"?"success":"warning"}">${c.verification_status}</span></div>${c.verification_status!=="geverifieerd"?`<div class="stack" style="margin-top:10px"><button class="btn btn-primary" onclick="verifyContractor('${c.id}')">Verifieer</button></div>`:""}</div>`).join("")}</div></div>`;
}
async function verifyContractor(id){ await api.request(`/api/admin/contractors/${id}/verify`,{method:"POST"}); location.reload(); }
async function loadPaymentAccount(){ const box=document.getElementById("payment-account-box"); if(!box) return; const account=await api.request("/api/payment-account"); box.innerHTML=`<div class="card panel"><h3>Stripe uitbetalingsaccount</h3><div class="info-row"><span>Status</span><span class="badge info">${account.account_status}</span></div><div class="small" style="margin-top:12px">Later kun je hier een echte Stripe Connect-koppeling aan hangen.</div><div class="stack" style="margin-top:14px"><button class="btn btn-primary" onclick="prepareStripeAccount()">Stripe-account voorbereiden</button></div></div>`; }
async function prepareStripeAccount(){ const result=await api.request("/api/payment-account/prepare",{method:"POST"}); alert(result.message); location.reload(); }

document.addEventListener("DOMContentLoaded", async ()=>{
  wireMenu(); wireCookies(); wireFaq(); setCurrentUserLabel();
  const reg=document.getElementById("register-form"); if(reg) reg.addEventListener("submit", e=>onRegister(e).catch(err=>alert(err.message)));
  const log=document.getElementById("login-form"); if(log) log.addEventListener("submit", e=>onLogin(e).catch(err=>alert(err.message)));
  const create=document.getElementById("create-project-form"); if(create){ if(!requireAuth()) return; await loadContractors().catch(err=>alert(err.message)); create.addEventListener("submit", e=>createProject(e).catch(err=>alert(err.message))); }
  const contact=document.getElementById("contact-form"); if(contact) contact.addEventListener("submit", e=>onContact(e).catch(err=>alert(err.message)));
  if(document.getElementById("customer-projects")){ if(!requireAuth()) return; await loadProjects("customer-projects","customer").catch(err=>showNotice("customer-projects", err.message)); }
  if(document.getElementById("contractor-projects")){ if(!requireAuth()) return; await loadProjects("contractor-projects","contractor").catch(err=>showNotice("contractor-projects", err.message)); await loadPaymentAccount().catch(()=>{}); }
  if(document.getElementById("project-detail")){ if(!requireAuth()) return; await loadProjectDetail().catch(err=>showNotice("project-detail", err.message)); }
  if(document.getElementById("payment-box")){ await loadPaymentPage().catch(err=>showNotice("payment-box", err.message)); }
  if(document.getElementById("admin-overview")){ if(!requireAuth()) return; await loadAdmin().catch(err=>showNotice("admin-overview", err.message)); }
});
